﻿namespace TacoBellFinder.Web.Models
{
    public class AzureStorageConfig
    {
        public string StorageConnectionString { get; set; }
    }
}
