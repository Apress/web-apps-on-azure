﻿CREATE TABLE [dbo].[Products]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [SKU] NVARCHAR(16) NOT NULL, 
    [Name] NVARCHAR(64) NOT NULL, 
    [Description] NVARCHAR(512) NOT NULL, 
    [NumberInStock] INT NOT NULL DEFAULT 0
)
