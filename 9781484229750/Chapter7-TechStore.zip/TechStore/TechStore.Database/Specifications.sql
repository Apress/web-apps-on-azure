﻿CREATE TABLE [dbo].[Specifications]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ProductId] INT NOT NULL, 
    [SpecName] NVARCHAR(64) NOT NULL, 
    [SpecValue] NVARCHAR(128) NOT NULL, 
    CONSTRAINT [FK_Specifications_Products] FOREIGN KEY (ProductId) 
        REFERENCES [Products]([Id])
)
