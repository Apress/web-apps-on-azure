﻿using System.Web.Mvc;
using TechStore.Web.Services;
using TechStore.Web.Models;
using System.Threading.Tasks;
using System.Diagnostics;

namespace TechStore.Web.Controllers
{
    public class HomeController : Controller
    {
        private IProductService _productService;
        private const long NANOSECONDS_PER_SECOND = 1000L * 1000L * 1000L;

        /// <summary>
        /// Constructor. In a production application, the IProductService instance
        /// should be injected by a Dependency Injection container. 
        /// To keep this illustration simple, we'll instantiate our IProductService 
        /// in the constructor. 
        /// </summary>
        public HomeController()
        {
            _productService = new ProductService();
        }

        /// <summary>
        /// Returns the home page that lists all products in the database. 
        /// </summary>
        [HttpGet]
        public async Task<ActionResult> Index()
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            ProductList allProducts = await _productService.RetrieveAllProducts();
            timer.Stop();

            long requestDuration =
               CalculateRequestDurationInMicroseconds(Stopwatch.Frequency,
               timer.ElapsedTicks);
            allProducts.RetrievalTime = requestDuration;
            return View(allProducts);
        }

        /// <summary>
        /// Returns a product details page for the requested product. 
        /// </summary>
        /// <param name="id">The ID for the products record that we'd like to 
        /// view. </param>
        [HttpGet]
        public async Task<ActionResult> Product(int id)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            ProductDetails product = await _productService.RetrieveProductDetails(id);
            timer.Stop();

            long requestDuration =
               CalculateRequestDurationInMicroseconds(Stopwatch.Frequency,
               timer.ElapsedTicks);
            product.RetrievalTime = requestDuration;
            return View(product);
        }

        /// <summary>
        /// Created the edit product page for the requested product. 
        /// </summary>
        [HttpGet]
        public async Task<ActionResult> EditProduct(int id)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            ProductDetails product = await _productService.RetrieveProductDetails(id);
            timer.Stop();

            long requestDuration =
               CalculateRequestDurationInMicroseconds(Stopwatch.Frequency,
               timer.ElapsedTicks);
            product.RetrievalTime = requestDuration;
            return View(product);
        }

        /// <summary>
        /// Updates the product's information. This will update the database 
        /// and evict any cache
        /// record for the edited product so that our cache won't serve stale data. 
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> EditProduct(ProductDetails product)
        {
            await _productService.UpdateProductDetails(product);
            return View(product);
        }

        /// <summary>
        /// Helper method that will take our timer's frequency and elapsed time in ticks, 
        /// and calculate the number of microseconds that the request took. 
        /// </summary>
        private long CalculateRequestDurationInMicroseconds(long stopWatchFrequency,
           long elapsedTicks)
        {
            long nanosecondsPerTick = NANOSECONDS_PER_SECOND / Stopwatch.Frequency;
            long requestLength = elapsedTicks * nanosecondsPerTick;
            return requestLength;
        }
    }
}
