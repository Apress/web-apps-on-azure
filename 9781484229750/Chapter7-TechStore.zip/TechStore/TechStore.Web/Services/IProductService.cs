﻿using TechStore.Web.Models;
using System.Threading.Tasks;

namespace TechStore.Web.Services
{
    public interface IProductService
    {
        Task<ProductList> RetrieveAllProducts();
        Task<ProductDetails> RetrieveProductDetails(int productId);
        Task UpdateProductDetails(ProductDetails product);
    }
}

