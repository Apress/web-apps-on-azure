﻿using System;
using System.Threading.Tasks;
using TechStore.Web.Models;
using TechStore.Web.Persistence;
using System.Data.Entity;
using System.Configuration;
using System.Linq;
using StackExchange.Redis;
using Newtonsoft.Json;

namespace TechStore.Web.Services
{
    /// <summary>
    /// This class is responsible for retrieving and updating product information. 
    /// </summary>
    public class ProductService : IProductService
    {
        private const string DATABASE_RETRIEVAL = "SQL Server Database";
        private const string REDIS_RETRIEVAL = "Redis Cache";
        private static ConnectionMultiplexer _redisConnection;

        /// <summary>
        /// Constructor that is only called once, no matter how many times this 
        /// class is instantiated. The ConnectionMultiplexer class is expensive, 
        /// and we do not want to recreate it for each request. 
        /// </summary>
        static ProductService()
        {
            string redisConnectionString =
               ConfigurationManager.AppSettings["redisCacheConnectionString"];
            _redisConnection = ConnectionMultiplexer.Connect(redisConnectionString);
        }

        /// <summary>
        /// Retrieves a list of all products from the database. Note that we are 
        /// not getting the Specifications since we're just listing products and 
        /// not viewing product details. 
        /// </summary>
        public async Task<ProductList> RetrieveAllProducts()
        {
            ProductList allProducts = await RetrieveAllProductsFromDatabase();
            return allProducts;
        }

        /// <summary>
        /// Retrieves a single product. We'll first look to see if the product is 
        /// in cache. If so, serve it. If not, retrieve it from the database, 
        /// add to cache, and then serve it. 
        /// </summary>
        public async Task<ProductDetails> RetrieveProductDetails(int productId)
        {
            ProductDetails product = await RetrieveProductFromCache(productId);
            if (product == null)
            {
                //we've had a cache miss. We're going to have to retrieve the product
                //from the database, then add it to cache before returning. 
                product = await RetrieveProductFromDatabase(productId);
                await AddProductToCache(product);
            }

            return product;
        }

        /// <summary>
        /// Updates the product in our database, then evicts the old stale record from cache. 
        /// </summary>
        public async Task UpdateProductDetails(ProductDetails product)
        {
            //first, update the product in our system of record. 
            await UpdateProductInDatabase(product);

            //next, kick the old product instance out of cache and replace it
            //with our updated instance.
            await AddProductToCache(product);
        }


        /// <summary>
        /// Convenience method for creating a Redis cache key for a product. 
        /// </summary>
        private string CreateProductCacheKey(int productId)
        {
            return "product:" + productId;
        }

        /// <summary>
        /// Checks our Redis Cache for the requested product. If found, we return the 
        /// ProductDetails record. If not, we return null. 
        /// </summary>
        private async Task<ProductDetails> RetrieveProductFromCache(int productId)
        {
            string productKey = "product:" + productId;
            IDatabase cache = _redisConnection.GetDatabase();
            string val = await cache.StringGetAsync(productKey);
            if (val == null)
            {
                //cache miss. We don't have this product cached yet. 
                return null;
            }

            ProductDetails product = JsonConvert.DeserializeObject<ProductDetails>(val);
            product.RetrievalMethod = REDIS_RETRIEVAL;
            return product;
        }

        /// <summary>
        /// Adds a product to our Redis Cache. 
        /// </summary>
        private async Task AddProductToCache(ProductDetails product)
        {
            string productKey = CreateProductCacheKey(product.Id);
            IDatabase cache = _redisConnection.GetDatabase();
            string serializedProduct = JsonConvert.SerializeObject(product);
            await cache.StringSetAsync(productKey, serializedProduct);
        }

        /// <summary>
        /// Retrieves a product from the database using the supplied primary key. 
        /// </summary>
        private async Task<ProductDetails> RetrieveProductFromDatabase(int productId)
        {
            ProductDetails product = null;
            using (var db = new TechStoreContext())
            {
                var productFromDb = await db.Products.Where(b =>
                   b.Id == productId).Include(b => b.Specifications).FirstOrDefaultAsync();
                if (productFromDb != null)
                {
                    product = CreateProductDetails(productFromDb);
                    product.RetrievalMethod = DATABASE_RETRIEVAL;
                }
            }
            return product;
        }

        /// <summary>
        /// Updates a Products record in the database. 
        /// </summary>
        private async Task UpdateProductInDatabase(ProductDetails product)
        {
            using (var db = new TechStoreContext())
            {
                var productFromDb = await db.Products.FindAsync(product.Id);
                if (productFromDb == null)
                {
                    throw new Exception("We couldn't find a product for Id " + product.Id);
                }

                productFromDb.Name = product.Name;
                productFromDb.Description = product.Description;
                productFromDb.SKU = product.SKU;
                productFromDb.NumberInStock = product.NumberInStock;

                await db.SaveChangesAsync();
                product.LastUpdatedMessage = "Successfully updated at " +
                   DateTime.Now.ToString("o");
            }
        }

        /// <summary>
        /// Retrieves all products from the database, stores them in a ProductList
        /// instance, and returns them to the caller. 
        /// </summary>
        /// <returns></returns>
        private async Task<ProductList> RetrieveAllProductsFromDatabase()
        {
            ProductList allProducts = new ProductList();
            allProducts.RetrievalMethod = DATABASE_RETRIEVAL;
            using (var db = new TechStoreContext())
            {
                var productsFromDb = await db.Products.ToListAsync();
                foreach (Product p in productsFromDb)
                {
                    allProducts.Products.Add(CreateProductDetails(p));
                }
            }
            return allProducts;
        }

        /// <summary>
        /// Copies data from our EF-generated Product class to our 
        /// ProductDetails view model class. 
        /// </summary>
        private ProductDetails CreateProductDetails(Product p)
        {
            ProductDetails details = new ProductDetails();
            details.Id = p.Id;
            details.Name = p.Name;
            details.Description = p.Description;
            details.SKU = p.SKU;
            details.NumberInStock = p.NumberInStock;

            //now let's set up our specifications
            foreach (Specification s in p.Specifications)
            {
                SpecificationDetails specDetail = new SpecificationDetails();
                specDetail.SpecName = s.SpecName;
                specDetail.SpecValue = s.SpecValue;
                details.Specifications.Add(specDetail);
            }
            return details;
        }
    }
}
