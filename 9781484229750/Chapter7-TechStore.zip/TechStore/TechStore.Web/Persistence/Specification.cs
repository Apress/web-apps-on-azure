namespace TechStore.Web.Persistence
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Specification
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        [Required]
        [StringLength(64)]
        public string SpecName { get; set; }

        [Required]
        [StringLength(128)]
        public string SpecValue { get; set; }

        public virtual Product Product { get; set; }
    }
}
