namespace TechStore.Web.Persistence
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class TechStoreContext : DbContext
    {
        public TechStoreContext()
            : base("name=TechStoreContext")
        {
        }

        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Specification> Specifications { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .HasMany(e => e.Specifications)
                .WithRequired(e => e.Product)
                .WillCascadeOnDelete(false);
        }
    }
}
