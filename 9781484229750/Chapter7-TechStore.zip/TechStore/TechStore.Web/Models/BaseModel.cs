﻿namespace TechStore.Web.Models
{
    /// <summary>
    /// All of our View Models will inherit from this class. It will contain 
    /// the retrieval method
    /// and retrieval time for servicing the request. 
    /// </summary>
    public class BaseModel
    {
        public string RetrievalMethod { get; set; }
        public decimal RetrievalTime { get; set; }

        /// <summary>
        /// Used only when we update an entity. This will transmit any notifications 
        /// from our service class to the view. 
        /// </summary>
        public string LastUpdatedMessage { get; set; }
    }
}
