﻿using System.Collections.Generic;

namespace TechStore.Web.Models
{
    /// <summary>
    /// This class is our MVC ViewModel for a product. 
    /// </summary>
    public class ProductDetails : BaseModel
    {
        public ProductDetails()
        {
            this.Specifications = new List<SpecificationDetails>();
        }

        public int Id { get; set; }

        /// <summary>
        /// A list of all specifications for this product. 
        /// </summary>
        public List<SpecificationDetails> Specifications { get; }
        public string SKU { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int NumberInStock { get; set; }
    }
}
