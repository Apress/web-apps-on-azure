﻿using System.Collections.Generic;

namespace TechStore.Web.Models
{
    public class ProductList : BaseModel
    {
        public ProductList()
        {
            this.Products = new List<ProductDetails>();
        }

        public List<ProductDetails> Products { get; set; }
    }
}
