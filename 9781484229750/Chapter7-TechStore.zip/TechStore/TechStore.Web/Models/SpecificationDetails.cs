﻿namespace TechStore.Web.Models
{
    public class SpecificationDetails
    {
        public string SpecName { get; set; }
        public string SpecValue { get; set; }
    }
}
